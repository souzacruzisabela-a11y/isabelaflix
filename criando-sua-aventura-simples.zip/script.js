const gameDiv = document.getElementById("game");

function startGame() {
    gameDiv.innerHTML = `
        <p>Você está diante de uma floresta misteriosa. O que deseja fazer?</p>
        <button onclick="escolher('entrar')">Entrar na floresta</button>
        <button onclick="escolher('voltar')">Voltar para casa</button>
    `;
}

function escolher(opcao) {
    if (opcao === 'entrar') {
        gameDiv.innerHTML = '<p>Você entrou na floresta e encontrou um dragão! 🐉</p>';
    } else {
        gameDiv.innerHTML = '<p>Você voltou para casa em segurança. 🏠</p>';
    }
}

startGame();